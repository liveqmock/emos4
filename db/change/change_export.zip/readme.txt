1.export_info.xml 导出操作说明文件
2.按照工单类型作为文件目录保存工单的导出文件
3.以工单类型命名的文件夹下面包括：
	a，workflow_info.xml 工单类型详细信息
	b, fields_info.xml 表单配置字段信息
	c, steps_info.xml 环节配置信息，内部包括环节字段配置信息，动作配置信息，以及与动作对应的字段关系信息。
	d, wfdesign文件夹下保存的是所有的流程图定义文件。
	e, jsp文件夹下面保存的是所有的jsp页面文件和js文件。